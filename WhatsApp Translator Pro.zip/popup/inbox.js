document.addEventListener('DOMContentLoaded', () => {
    const messageList = document.getElementById('messageList');
    const totalCountEl = document.getElementById('totalCount');
    const backBtn = document.getElementById('backBtn');
    
    // 详情页相关元素
    const detailView = document.getElementById('detailView');
    const detailTitle = document.getElementById('detailTitle');
    const detailDate = document.getElementById('detailDate');
    const detailBody = document.getElementById('detailBody');
    const detailBackBtn = document.getElementById('detailBackBtn');
    const detailDeleteBtn = document.getElementById('detailDeleteBtn');
    
    // 模拟数据 (实际应从 storage 或 API 获取)
    // type: 'system' | 'account' | 'alert'
    // const mockMessages = [ ... ]; // 注释掉模拟数据

    // 初始化渲染 (移至 fetchMyMessages 调用后)
    // renderMessages(mockMessages);

    // 绑定返回按钮
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            window.location.href = 'popup.html';
        });
    }

    // --- 新增：全部已读功能 (静默模式) ---
    const readAllBtn = document.getElementById('readAllBtn');
    if (readAllBtn) {
        readAllBtn.addEventListener('click', () => {
            // 添加旋转动画反馈
            readAllBtn.classList.add('rotating');
            
            chrome.storage.local.get(['user'], (res) => {
                const user = res.user;
                if (!user) {
                    readAllBtn.classList.remove('rotating');
                    return;
                }
                const username = user.username || user.identifier || (user.email ? user.email.split('@')[0] : null);
                const storageKey = `readIds_${username}`;

                chrome.storage.local.get([storageKey], (storage) => {
                    const readIds = storage[storageKey] || [];
                    const items = document.querySelectorAll('.message-item');
                    
                    // 标记所有当前显示的消息
                    items.forEach(item => {
                        const id = item.dataset.id;
                        if (!readIds.includes(id)) {
                            readIds.push(id);
                        }
                        // 立即更新 UI
                        item.classList.remove('unread');
                        const dot = item.querySelector('.unread-dot');
                        if (dot) dot.remove();
                    });

                    // 保存到本地存储
                    chrome.storage.local.set({ [storageKey]: readIds }, () => {
                        // 延迟移除动画并显示成功反馈
                        setTimeout(() => {
                            readAllBtn.classList.remove('rotating');
                            showToast('已全部标记为已读');
                        }, 500);
                    });
                });
            });
        });
    }

    // 轻量级 Toast 提示函数
    function showToast(message) {
        let toast = document.getElementById('inboxToast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'inboxToast';
            toast.style.cssText = `
                position: fixed;
                bottom: 20px;
                left: 50%;
                transform: translateX(-50%);
                background: rgba(0,0,0,0.7);
                color: white;
                padding: 8px 16px;
                border-radius: 4px;
                font-size: 13px;
                z-index: 200;
                opacity: 0;
                transition: opacity 0.3s;
            `;
            document.body.appendChild(toast);
        }
        
        toast.textContent = message;
        toast.style.opacity = '1';
        
        setTimeout(() => {
            toast.style.opacity = '0';
        }, 2000);
    }

    function renderMessages(messages) {
        if (messages.length === 0) {
            messageList.innerHTML = ''; // 彻底清空，不显示任何占位符
            totalCountEl.textContent = '0';
            return;
        }

        totalCountEl.textContent = messages.length;
        messageList.innerHTML = messages.map(msg => createMessageHTML(msg)).join('');

        // 绑定点击查看详情
        document.querySelectorAll('.message-item').forEach(item => {
            item.addEventListener('click', () => {
                const id = item.dataset.id; // 直接作为字符串处理
                const msg = messages.find(m => String(m.id) === id);
                if (msg) showDetail(msg);
            });
        });

        // 绑定删除按钮事件
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation(); // 防止触发点击消息
                const id = btn.dataset.id;
                if(confirm('确定删除这条消息吗？')) {
                    const el = btn.closest('.message-item');
                    el.style.opacity = '0';
                    setTimeout(() => el.remove(), 200);
                    // TODO: 同步删除数据
                }
            });
        });
    }

    function showDetail(msg) {
        detailTitle.textContent = msg.title;
        detailDate.textContent = msg.date;
        detailBody.innerHTML = msg.content.replace(/\n/g, '<br>'); // 支持换行
        
        // 标记当前详情页的 ID，用于删除
        detailDeleteBtn.dataset.id = msg.id;
        
        detailView.style.display = 'flex';
        
        // --- 新增：标记为已读并保存到用户特定的 storage ---
        chrome.storage.local.get(['user'], (res) => {
            const user = res.user;
            if (!user) return;
            const username = user.username || user.identifier || (user.email ? user.email.split('@')[0] : null);
            const storageKey = `readIds_${username}`;

            chrome.storage.local.get([storageKey], (storage) => {
                const readIds = storage[storageKey] || [];
                if (!readIds.includes(msg.id)) {
                    readIds.push(msg.id);
                    chrome.storage.local.set({ [storageKey]: readIds });
                    
                    // 同时更新 UI 上的未读状态
                    const item = document.querySelector(`.message-item[data-id="${msg.id}"]`);
                    if (item) {
                        item.classList.remove('unread');
                        const dot = item.querySelector('.unread-dot');
                        if (dot) dot.remove();
                    }
                }
            });
        });
    }

    // 详情页返回
    if (detailBackBtn) {
        detailBackBtn.addEventListener('click', () => {
            detailView.style.display = 'none';
        });
    }

    // 详情页删除
    if (detailDeleteBtn) {
        detailDeleteBtn.addEventListener('click', () => {
            const id = detailDeleteBtn.dataset.id;
            if(confirm('确定删除这条消息吗？')) {
                // 删除列表项
                const item = document.querySelector(`.message-item[data-id="${id}"]`);
                if (item) item.remove();
                
                // 关闭详情页
                detailView.style.display = 'none';
                
                // 更新总数 (模拟)
                totalCountEl.textContent = parseInt(totalCountEl.textContent) - 1;
            }
        });
    }

    // --- 新增：获取站内信 ---
    const API_BASE_URL = "https://nexusproxy.asia"; 

    // 获取当前用户信息
    chrome.storage.local.get(['user'], (result) => {
        console.log('Inbox: Storage check:', result);
        const user = result.user;
        if (user) {
            // 尝试获取用户名：优先 username，其次 identifier，最后是 email 的前缀
            const username = user.username || user.identifier || (user.email ? user.email.split('@')[0] : null);
            
            if (username) {
                console.log('Inbox: Fetching messages for:', username);
                fetchMyMessages(username);
            } else {
                console.warn('Inbox: No username found in user object');
                messageList.innerHTML = '';
            }
        } else {
            console.log('Inbox: No user logged in');
            messageList.innerHTML = '';
            totalCountEl.textContent = '0';
        }
    });

    async function fetchMyMessages(username) {
        try {
            const response = await fetch(`${API_BASE_URL}/api/user/station_letters?username=${encodeURIComponent(username)}`);
            const result = await response.json();
            
            console.log("收到的站内信原始数据:", result);
            
            // 兼容直接返回数组或返回包含 data 字段的对象
            const messages = Array.isArray(result) ? result : (result.data || []);
            
            if (Array.isArray(messages)) {
                // 按时间倒序排列 (最新的在最前)
                messages.sort((a, b) => {
                    const dateA = new Date(a.created_at || a.date).getTime();
                    const dateB = new Date(b.created_at || b.date).getTime();
                    return dateB - dateA;
                });

                // 获取用户特定的已读记录键名
                const storageKey = `readIds_${username}`;
                chrome.storage.local.get([storageKey], (storage) => {
                    // 确保存储的 ID 都是字符串格式，避免类型不匹配问题
                    const readIds = (storage[storageKey] || []).map(String);
                    
                    // 转换后端数据格式适配前端渲染
                    const formattedMessages = messages.map(msg => ({
                        id: String(msg.id), // 强制转为字符串
                        type: msg.type === 'personal' ? 'account' : 'system', // 映射类型
                        title: msg.title,
                        date: msg.created_at,
                        content: msg.content,
                        read: readIds.includes(String(msg.id)) // 强制字符串比较
                    }));
                    
                    renderMessages(formattedMessages);
                });
            } else {
                 renderMessages([]);
            }
        } catch (error) {
            console.error("获取站内信失败:", error);
            messageList.innerHTML = '<div class="empty-state">加载失败，请检查网络</div>';
        }
    }

    function createMessageHTML(msg) {
        let iconSvg = '';
        if (msg.type === 'system') {
            iconSvg = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L1 21h22L12 2zm0 3.99L19.53 19H4.47L12 5.99zM11 16h2v2h-2zm0-6h2v4h-2z"/></svg>'; // 警告/通知图标
            if (msg.title.includes('激活')) { // 特殊图标
                iconSvg = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>'; // 对勾
            }
        } else if (msg.type === 'account') {
            iconSvg = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>'; // 人物
        }

        return `
            <div class="message-item ${msg.read ? '' : 'unread'}" data-id="${msg.id}">
                ${msg.read ? '' : '<div class="unread-dot"></div>'}
                <div class="msg-icon ${msg.type}">
                    ${iconSvg}
                </div>
                <div class="msg-content">
                    <div class="msg-header">
                        <span class="msg-title">${msg.title}</span>
                        <span class="msg-date">${msg.date}</span>
                    </div>
                    <div class="msg-preview">${msg.content}</div>
                </div>
                <!-- 删除了 delete-btn -->
            </div>
        `;
    }
});