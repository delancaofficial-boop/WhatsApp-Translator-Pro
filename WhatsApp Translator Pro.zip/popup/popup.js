document.addEventListener('DOMContentLoaded', () => {
    // --- 新增：页面状态持久化 ---
    chrome.storage.local.get(['isLoggedIn', 'lastPage'], (res) => {
        if (!res.isLoggedIn && res.lastPage && res.lastPage !== 'popup.html' && res.lastPage !== 'login.html') {
            // 如果未登录且存在上次离开的子页面，则自动跳转回去
            console.log('恢复上次访问的页面:', res.lastPage);
            window.location.href = res.lastPage;
            return;
        }
        
        // 如果是登录状态，或者是从登录页进来的，正常执行逻辑
        initMain();
    });

    // 初始化主界面
    function initMain() {
        // --- 鉴权与用户信息展示 ---
        chrome.storage.local.get(['isLoggedIn', 'user'], (result) => {
        if (!result.isLoggedIn) {
            // 保持 URL 参数进行跳转，以便在登录页也能恢复弹窗请求
            const currentParams = window.location.search;
            window.location.href = 'login.html' + currentParams;
            return;
        }

        // 更新用户信息
        const user = result.user || {};
        const email = user.email || user.identifier || 'user@example.com';
        let expireDate = user.expiry_date || user.expire_at || '未开通';

        // 检查会员有效性
        const isValid = isMembershipValid(user);
        const statusToggle = document.getElementById('translationStatus');
        const statusText = document.getElementById('statusText');

        // 核心逻辑调整：只有当明确有过期日期且已过期时，才强制禁用
        // 如果没有日期数据（刚登录），则先不禁用，等待 syncUserProfile 同步
        const hasDate = !!(user.expiry_date || user.expire_at);

        if (hasDate && !isValid) {
            // 明确已过期
            chrome.storage.local.set({ translationStatus: false });
            if (statusToggle) {
                statusToggle.checked = false;
                statusToggle.disabled = true;
                statusToggle.title = "会员已到期，请续费后使用";
            }
            if (statusText) {
                statusText.textContent = '已停用 (会员到期)';
                statusText.style.color = '#f44336';
            }
            toggleFoldableArea(false);
        } else {
            // 有效会员 或 暂无日期数据(同步中) -> 保持可用
            if (statusToggle) {
                statusToggle.disabled = false;
                statusToggle.title = "";
            }
        }

        // 处理永久会员
        const isPermanent = expireDate === '永久';
        const expireEl = document.getElementById('expireDate');
        const renewBtn = document.querySelector('.renew-btn');

        if (expireEl) {
            expireEl.textContent = expireDate;
        }

        if (isPermanent && renewBtn) {
            renewBtn.textContent = '永久会员';
            renewBtn.style.backgroundColor = '#4caf50'; // 保持绿色
            renewBtn.style.cursor = 'default';
            renewBtn.disabled = true; // 永久会员不需要续费
            // 彻底移除点击事件，防止跳转
            renewBtn.replaceWith(renewBtn.cloneNode(true));
        } else if (renewBtn) {
            renewBtn.textContent = '续费';
            renewBtn.disabled = false;
            renewBtn.style.cursor = 'pointer';
        }

        // 更新头像的 tooltip 显示邮箱
        const avatarEl = document.getElementById('userAvatar');

        // 绑定站内信跳转
        const inboxLink = document.querySelector('.inbox-link');
        if (inboxLink) {
            inboxLink.addEventListener('click', () => {
                window.location.href = 'inbox.html';
            });
        }

        // --- 新增：检查未读站内信 ---
        checkUnreadMessages(user);

        // --- 新增：同步用户最新状态 (解决后台修改后插件不更新的问题) ---
        syncUserProfile(user);

        // 绑定续费按钮跳转
        const renewBtns = document.querySelectorAll('.renew-btn');
        renewBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                window.location.href = 'renew.html';
            });
        });
    });

    // --- 客服与服务列表逻辑已移至 modal.js 统一处理 ---

    // 会员有效性检查辅助函数
    function isMembershipValid(user) {
        if (!user) return false;
        // 同时支持 expiry_date 和 expire_at 字段
        const expireDate = user.expiry_date || user.expire_at;
        if (expireDate === '永久' || expireDate === '永久会员') return true;
        if (!expireDate || expireDate === '未开通' || expireDate === '无') return false;

        try {
            const now = new Date();
            // 获取北京时间 (UTC+8)
            const beijingOffset = 8 * 60; // 分钟
            const localOffset = now.getTimezoneOffset(); // 分钟
            const beijingTime = new Date(now.getTime() + (beijingOffset + localOffset) * 60000);
            
            const y = beijingTime.getFullYear();
            const m = String(beijingTime.getMonth() + 1).padStart(2, '0');
            const d = String(beijingTime.getDate()).padStart(2, '0');
            const todayStr = `${y}-${m}-${d}`;

            // 字符串比较即可: "2024-05-21" >= "2024-05-20"
            return expireDate >= todayStr;
        } catch (e) {
            console.error('Membership date check failed:', e);
            return false;
        }
    }

  // 退出登录
  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      // 使用新的统一样式弹窗
      if (window.showConfirmModal) {
          window.showConfirmModal({
              title: '确认退出登录',
              content: '确定要退出登录吗？',
              confirmText: '确认退出',
              onConfirm: () => {
                  chrome.storage.local.set({ isLoggedIn: false, user: null }, () => {
                      window.location.href = 'login.html';
                  });
              }
          });
      } else {
          // 降级处理
          if (confirm('确定要退出登录吗？')) {
              chrome.storage.local.set({ isLoggedIn: false, user: null }, () => {
                  window.location.href = 'login.html';
              });
          }
      }
    });
  }
  // --- 鉴权逻辑结束 ---

  // Load settings
  chrome.storage.local.get([
    'translationStatus',
    'engine',
    'sourceLang',
    'targetLang',
    'smartDetect',
    'autoTranslate',
    'quickTranslate',
    'quickKey',
    'customShortcut'
  ], (result) => {
    document.getElementById('translationStatus').checked = result.translationStatus !== false;
    document.getElementById('engine').value = result.engine || 'google';
    document.getElementById('sourceLang').value = result.sourceLang || 'zh-CN';
    document.getElementById('targetLang').value = result.targetLang || 'en';
    document.getElementById('smartDetect').checked = result.smartDetect || false;
    document.getElementById('autoTranslate').checked = result.autoTranslate !== false;
    document.getElementById('quickTranslate').checked = result.quickTranslate !== false;
    
    // 快速翻译模式回显
    const quickKey = result.quickKey || 'shortcut';
    const quickKeyRadio = document.querySelector(`input[name="quickKey"][value="${quickKey}"]`);
    if (quickKeyRadio) quickKeyRadio.checked = true;

    // 快捷键回显
    const shortcutInput = document.getElementById('shortcutKey');
    // shortcutInput.value = result.customShortcut || 'Ctrl+Shift+Z'; // 移除

    // UI 联动
    toggleShortcutLink(quickKey === 'shortcut');
    toggleEnterNote(quickKey === 'enter');
    
    // 初始化折叠状态
    toggleFoldableArea(result.translationStatus !== false);
  });

  // 监听单选切换，控制 UI 状态
  document.querySelectorAll('input[name="quickKey"]').forEach(radio => {
    radio.addEventListener('change', (e) => {
      const isShortcut = e.target.value === 'shortcut';
      toggleShortcutLink(isShortcut);
      toggleEnterNote(!isShortcut);
      saveSettings();
    });
  });

  // 监听总开关切换，控制折叠
  document.getElementById('translationStatus').addEventListener('change', (e) => {
    toggleFoldableArea(e.target.checked);
  });

  function toggleFoldableArea(enable) {
    const area = document.getElementById('foldableSettings');
    const statusText = document.getElementById('statusText');
    
    if (area) {
        if (enable) {
            // 展开：设置高度为内容高度
            area.style.maxHeight = area.scrollHeight + "px";
            area.style.opacity = "1";
        } else {
            // 折叠：高度为0
            area.style.maxHeight = "0";
            area.style.opacity = "0.5";
        }
    }

    if (statusText) {
        statusText.textContent = enable ? '已开启' : '已停用';
        statusText.style.color = enable ? '#4caf50' : '#999';
    }
  }

  // 打开浏览器快捷键设置页
  document.getElementById('openShortcuts').addEventListener('click', (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });
  });

  // Save settings on change

    // Save settings on change
    const inputs = document.querySelectorAll('input, select');
    inputs.forEach(input => {
        // 关键修复：移除 disabled 检查，确保所有输入框都能绑定事件
        // 之前的逻辑可能被其他代码影响，这里强制重新绑定
        input.removeEventListener('change', saveSettings); 
        input.addEventListener('change', saveSettings);
    });

    // 手动触发一次状态检查，确保 UI 正确
    const statusToggleBtn = document.getElementById('translationStatus');
    if (statusToggleBtn) {
        toggleFoldableArea(statusToggleBtn.checked);
    }

  function saveSettings() {
      const settings = {
        translationStatus: document.getElementById('translationStatus').checked,
        engine: document.getElementById('engine').value,
        sourceLang: document.getElementById('sourceLang').value,
        targetLang: document.getElementById('targetLang').value,
        smartDetect: document.getElementById('smartDetect').checked,
        autoTranslate: document.getElementById('autoTranslate').checked,
        quickTranslate: document.getElementById('quickTranslate').checked,
        quickKey: document.querySelector('input[name="quickKey"]:checked').value
      };
      
      chrome.storage.local.set(settings, () => {
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
          if (tabs[0]?.id && tabs[0].url?.includes('web.whatsapp.com')) {
            try {
              chrome.tabs.sendMessage(tabs[0].id, {type: 'SETTINGS_UPDATED', settings})
                .catch(err => console.log('Content script not ready yet:', err));
            } catch (e) {
              console.log('Error sending message:', e);
            }
          }
        });
      });
  }

  function toggleShortcutLink(enable) {
    const link = document.getElementById('openShortcuts');
    link.style.opacity = enable ? '1' : '0.5';
    link.style.pointerEvents = enable ? 'auto' : 'none';
  }

  function toggleEnterNote(enable) {
    const note = document.getElementById('enterNote');
    if (note) {
        note.style.display = enable ? 'block' : 'none';
    }
  }

  // --- 新增：同步用户状态逻辑 ---
  async function syncUserProfile(user) {
    if (!user) return;
    
    // 使用 email 或 username 作为查询标识
    const identifier = user.username || user.identifier || (user.email ? user.email.split('@')[0] : null);
    // 注意：之前测试发现 /api/user/info?username=123456 是通的，所以尽量用 username
    
    if (!identifier) return;

    try {
        const API_BASE_URL = "https://nexusproxy.asia";
        // 尝试调用用户信息接口
        const response = await fetch(`${API_BASE_URL}/api/user/info?username=${encodeURIComponent(identifier)}`);
        
        if (response.ok) {
            const result = await response.json();
            if (result.success && result.data) {
                // 合并数据
                let newUser = { ...user, ...result.data };
                let hasUpdate = false;

                // 智能同步日期
                const remoteDateStr = result.data.expiry_date || result.data.expire_at;
                if (remoteDateStr) {
                    const localDateStr = user.expiry_date || user.expire_at || '1970-01-01';
                    
                    // 1. 如果后端是永久，直接覆盖
                    if (remoteDateStr === '永久') {
                        newUser.expiry_date = '永久';
                        hasUpdate = true;
                    } 
                    // 2. 如果本地是永久，且后端不是，则保留本地（用户刚买永久，后台未同步）
                    else if (localDateStr === '永久') {
                        // 不更新
                    } 
                    // 3. 比较具体日期：只有当后端时间 > 本地时间，才覆盖本地
                    // 这样可以防止：用户刚买会员(本地增加)，但后台还是旧时间，导致同步后会员丢失
                    else {
                        const remoteTime = new Date(remoteDateStr).getTime();
                        const localTime = new Date(localDateStr).getTime();
                        
                        // 只有当后台时间 严格大于 本地时间时，才允许更新
                        // 这样就彻底防止了“回滚”
                        if (!isNaN(remoteTime) && !isNaN(localTime)) {
                            if (remoteTime > localTime) {
                                newUser.expiry_date = remoteDateStr;
                                hasUpdate = true;
                                console.log(`[同步更新] 后台时间(${remoteDateStr}) > 本地时间(${localDateStr})，执行更新`);
                            } else {
                                console.log(`[同步拦截] 后台时间(${remoteDateStr}) <= 本地时间(${localDateStr})，保留本地新时间`);
                            }
                        } else if (!isNaN(remoteTime)) {
                            // 本地时间无效，直接用后台的
                            newUser.expiry_date = remoteDateStr;
                            hasUpdate = true;
                        }
                    }
                }

                // 同步余额 (如果有)
                if (result.data.balance !== undefined) {
                    newUser.balance = result.data.balance;
                    hasUpdate = true;
                }

                if (hasUpdate) {
                    chrome.storage.local.set({ user: newUser }, () => {
                        console.log('用户状态已从后台同步:', newUser);
                        
                        // 1. 更新过期时间文本
                        const expireEl = document.getElementById('expireDate');
                        let expireDate = newUser.expiry_date || newUser.expire_at || '未开通';
                        if (expireEl) expireEl.textContent = expireDate;

                        // 2. 核心修复：同步完成后重新检查会员有效性，并恢复开关状态
                        const isValid = isMembershipValid(newUser);
                        const statusToggle = document.getElementById('translationStatus');
                        const statusText = document.getElementById('statusText');

                        if (isValid && statusToggle) {
                            statusToggle.disabled = false;
                            statusToggle.title = ""; // 清除提示
                            // 如果之前是因为到期被强制关闭的，这里可以保持关闭，让用户手动开启
                            // 但必须解除禁用
                            if (statusText && statusText.textContent.includes('会员到期')) {
                                statusText.textContent = '已停用';
                                statusText.style.color = '#999';
                            }
                        }

                        // 3. 处理永久会员按钮
                        const renewBtn = document.querySelector('.renew-btn');
                        if (expireDate === '永久' && renewBtn) {
                            renewBtn.textContent = '永久会员';
                            renewBtn.style.backgroundColor = '#4caf50';
                            renewBtn.disabled = true;
                            renewBtn.replaceWith(renewBtn.cloneNode(true));
                        }
                    });
                } else {
                    console.log('后台接口未返回有效日期字段 (expiry_date)，跳过同步。请在后台完善该接口。');
                }
            }
        }
    } catch (error) {
        console.warn('同步用户状态失败 (网络或接口错误):', error);
    }
  }

  // --- 新增：检查未读站内信逻辑 ---
  async function checkUnreadMessages(user) {
    const badge = document.getElementById('inboxBadge');
    if (!badge || !user) return;

    // 优先使用 username，其次 identifier，最后 email 前缀
    const username = user.username || user.identifier || (user.email ? user.email.split('@')[0] : null);
    if (!username) return;

    try {
      const API_BASE_URL = "https://nexusproxy.asia";
      const response = await fetch(`${API_BASE_URL}/api/user/station_letters?username=${encodeURIComponent(username)}`);
      const result = await response.json();
      const messages = Array.isArray(result) ? result : (result.data || []);

      if (Array.isArray(messages) && messages.length > 0) {
        // 使用用户特定的已读记录键名
        const storageKey = `readIds_${username}`;
        chrome.storage.local.get([storageKey], (storage) => {
          // 确保存储的 ID 都是字符串格式
          const readIds = (storage[storageKey] || []).map(String);
          
          // 比较时强制转为字符串
          const unreadCount = messages.filter(msg => !readIds.includes(String(msg.id))).length;

          if (unreadCount > 0) {
            badge.textContent = unreadCount > 99 ? '99+' : unreadCount;
            badge.style.display = 'flex';
          } else {
            badge.style.display = 'none';
          }
        });
      } else {
        badge.style.display = 'none';
      }
    } catch (error) {
      console.error('检查未读消息失败:', error);
      badge.style.display = 'none';
    }
  }
  } // 闭合 initMain
});
