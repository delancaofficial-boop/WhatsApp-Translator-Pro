// auth.js - 处理登录和注册逻辑 (对接真实后台)

// 配置 API 基础地址 (请根据实际情况修改)
const API_BASE_URL = 'https://nexusproxy.asia/api'; 

document.addEventListener('DOMContentLoaded', () => {
  // --- 新增：页面状态恢复与输入缓存 ---
  const currentPage = window.location.pathname.split('/').pop();
  
  // 1. 恢复缓存的输入内容
  chrome.storage.local.get(['cachedInputs', 'lastPage'], (res) => {
    // 如果不是当前页面，且存储了 lastPage，则可能需要重定向 (由 popup.js 统一处理，此处仅做辅助)
    
    if (res.cachedInputs) {
      const inputs = res.cachedInputs;
      // 登录页
      if (document.getElementById('email') && inputs.loginEmail) {
        document.getElementById('email').value = inputs.loginEmail;
      }
      // 注册页
      if (document.getElementById('emailPrefix') && inputs.registerPrefix) {
        document.getElementById('emailPrefix').value = inputs.registerPrefix;
      }
    }

    // 2. 记录当前页面
    chrome.storage.local.set({ lastPage: currentPage });
  });

  // 监听所有返回登录的链接，清除持久化状态
  document.querySelectorAll('a[href="login.html"]').forEach(link => {
    link.addEventListener('click', () => {
      chrome.storage.local.remove(['lastPage']);
    });
  });

  // 3. 监听输入并缓存
  const inputEmail = document.getElementById('email');
  const inputPrefix = document.getElementById('emailPrefix');

  if (inputEmail) {
    inputEmail.addEventListener('input', (e) => {
      chrome.storage.local.get(['cachedInputs'], (res) => {
        const cached = res.cachedInputs || {};
        cached.loginEmail = e.target.value;
        chrome.storage.local.set({ cachedInputs: cached });
      });
    });
  }

  if (inputPrefix) {
    inputPrefix.addEventListener('input', (e) => {
      chrome.storage.local.get(['cachedInputs'], (res) => {
        const cached = res.cachedInputs || {};
        cached.registerPrefix = e.target.value;
        chrome.storage.local.set({ cachedInputs: cached });
      });
    });
  }

  // 清除状态的辅助函数
  function clearAuthPersistence() {
    chrome.storage.local.remove(['lastPage', 'cachedInputs']);
  }

  // --- 原有逻辑开始 ---
  // 1. 密码显示/隐藏切换
  const togglePassword = document.getElementById('togglePassword');
  const passwordInput = document.getElementById('password');
  
  if (togglePassword && passwordInput) {
    togglePassword.addEventListener('click', () => {
      const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
      passwordInput.setAttribute('type', type);
      togglePassword.style.color = type === 'text' ? '#4caf50' : '#999';
    });
  }

  // 2. 发送验证码 (对接 API)
  const sendCodeBtn = document.getElementById('sendCodeBtn');
  if (sendCodeBtn) {
    sendCodeBtn.addEventListener('click', async () => {
      if (sendCodeBtn.disabled) return;
      
      const emailPrefix = document.getElementById('emailPrefix').value;
      if (!emailPrefix) {
        alert('请输入邮箱前缀');
        return;
      }
      
      const email = emailPrefix + document.getElementById('emailSuffix').value;

      try {
        sendCodeBtn.disabled = true;
        sendCodeBtn.textContent = '发送中...';

        // --- 发送请求给后台 ---
        // 接口文档: /register/send-code
        const response = await fetch(`${API_BASE_URL}/register/send-code`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ email: email })
        });
        
        const result = await response.json();
        
        // 假设后台返回结构是 { code: 200, msg: "success" } 或 { success: true }
        // 这里根据通用习惯判断，如果你的后台返回结构不同，请告诉我
        if (response.ok && (result.code === 200 || result.success)) {
          window.alert('验证码已发送，请查收邮件（10分钟内有效）');
          startCountdown();
        } else {
          console.warn('API调用失败:', result);
          window.alert(result.msg || result.message || '发送失败，请重试');
          sendCodeBtn.disabled = false;
          sendCodeBtn.textContent = '发送验证码';
        }
      } catch (error) {
        console.error('发送验证码错误:', error);
        window.alert('网络错误，请稍后重试');
        sendCodeBtn.disabled = false;
        sendCodeBtn.textContent = '发送验证码';
      }

      function startCountdown() {
        let count = 60;
        sendCodeBtn.style.color = '#999';
        const timer = setInterval(() => {
          count--;
          sendCodeBtn.textContent = `${count}s后重发`;
          if (count <= 0) {
            clearInterval(timer);
            sendCodeBtn.disabled = false;
            sendCodeBtn.textContent = '发送验证码';
            sendCodeBtn.style.color = '#7e57c2';
          }
        }, 1000);
      }
    });
  }

  // 3. 注册逻辑 (对接 API)
  const registerForm = document.getElementById('registerForm');
  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const email = (document.getElementById('emailPrefix').value + document.getElementById('emailSuffix').value).trim();
      const code = document.getElementById('verifyCode').value.trim();
      const password = document.getElementById('password').value;

      const submitBtn = registerForm.querySelector('.submit-btn');
      submitBtn.disabled = true;
      submitBtn.textContent = '注册中...';

      try {
        // --- 发送注册请求 ---
         // 接口文档: /register
         const response = await fetch(`${API_BASE_URL}/register`, {
           method: 'POST',
           headers: { 'Content-Type': 'application/json' },
           body: JSON.stringify({
             email: email,
             username: email.split('@')[0], // 默认用邮箱前缀当用户名
             password: password,
             code: code
           })
         });
 
         const result = await response.json();
 
         if (response.ok && (result.code === 200 || result.success)) {
           // 注册成功后自动保存登录状态
           let userData = result.data || { email: email };
           
           // 新增：如果后端没返回过期时间，前端计算赠送1天 (当天北京时间 + 1天)
          // 新增：如果后端没返回过期时间，前端计算赠送1天 (当天北京时间 + 1天)
          if (!userData.expiry_date && !userData.expire_at) {
            // 获取北京时间当前日期
            const now = new Date();
            const beijingOffset = 8 * 60; // 分钟
            const localOffset = now.getTimezoneOffset(); // 分钟 (通常是负数)
            const beijingTime = new Date(now.getTime() + (beijingOffset + localOffset) * 60000);
            
            // 增加1天
            beijingTime.setDate(beijingTime.getDate() + 1);
            
            // 格式化为 YYYY-MM-DD
            const y = beijingTime.getFullYear();
            const m = String(beijingTime.getMonth() + 1).padStart(2, '0');
            const d = String(beijingTime.getDate()).padStart(2, '0');
            userData.expiry_date = `${y}-${m}-${d}`;
            
            // 重要：同步更新后端状态（可选，如果后端不存储，则仅前端有效）
            // 这里我们主要保证前端展示正确
          } else {
             // 确保使用后端返回的有效字段名
             userData.expiry_date = userData.expiry_date || userData.expire_at;
          }
           
           chrome.storage.local.set({
             user: userData,
             token: result.token || result.data?.token,
             isLoggedIn: true
           }, () => {
             // 清除持久化状态
             clearAuthPersistence();
             
             // 关键修复：确保数据写入后再弹窗，并在弹窗关闭后才跳转
             window.alert('注册成功！已赠送1天会员体验');
             
             // 监听弹窗关闭事件或者简单的延迟跳转
             setTimeout(() => {
                 window.location.href = 'popup.html?new_register=true'; // 带上新注册标记
             }, 1500);
           });
        } else {
          // 优化错误提示：如果是验证码相关的英文错误，统一转为中文“验证码错误”
          let msg = result.msg || result.message || '注册失败';
          if (msg.includes('Invalid code') || msg.includes('expired') || msg.includes('code error')) {
            msg = '验证码错误';
          }
          window.alert(msg);
        }
      } catch (error) {
        console.error('注册错误:', error);
        window.alert('网络连接失败');
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = '注册';
      }
    });
  }

  // 4. 登录逻辑 (对接 API)
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;
      
      const submitBtn = loginForm.querySelector('.submit-btn');
      submitBtn.disabled = true;
      submitBtn.textContent = '登录中...';

      try {
        // ... (省略请求体构建)
        const requestBody = {
            identifier: email, 
            password: password
        };
        console.log('正在登录:', `${API_BASE_URL}/login`, requestBody);

        const response = await fetch(`${API_BASE_URL}/login`, {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          body: JSON.stringify(requestBody)
        });

        const result = await response.json();
        console.log('登录响应:', result);

        if (response.ok && result.success) {
          // 登录成功
          chrome.storage.local.set({
            user: result.user || { identifier: email }, // 保存后台返回的用户信息(含余额)
            token: result.token || 'logged_in', // Flask session通常不返token，只要登录态即可，这里存个标记
            isLoggedIn: true
          }, () => {
            // 清除持久化状态
            clearAuthPersistence();
            window.location.href = 'popup.html';
          });
        } else {
           window.alert(result.message || '账号或密码错误');
        }
      } catch (error) {
        console.error('登录详细错误:', error);
        window.alert('登录请求失败：' + error.message);
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = '登录';
      }
    });
  }
});
