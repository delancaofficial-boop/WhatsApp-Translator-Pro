// popup/modal.js

// 注入 HTML 结构
function initModalStructure() {
    if (document.getElementById('customModalOverlay')) return;

    const html = `
    <div id="customModalOverlay" class="custom-modal-overlay">
        <div class="custom-modal">
            <div class="custom-modal-header">
                <!-- WhatsApp 风格图标 -->
                <svg class="custom-modal-icon" viewBox="0 0 24 24">
                    <path fill="currentColor" d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0 0 12.04 2zM12 18c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z"/>
                    <path fill="currentColor" d="M10 13.5l-2.5-2.5 1.41-1.41L10 10.67l4.09-4.09 1.41 1.41z"/>
                </svg>
                <span class="custom-modal-title" id="customModalTitle">提示</span>
            </div>
            <div class="custom-modal-body" id="customModalBody"></div>
            <div class="custom-modal-footer" id="customModalFooter"></div>
        </div>
    </div>`;
    
    document.body.insertAdjacentHTML('beforeend', html);

    // 绑定遮罩点击关闭
    const overlay = document.getElementById('customModalOverlay');
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) closeModal();
    });

    // 绑定 ESC 关闭
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && overlay.classList.contains('active')) {
            closeModal();
        }
    });
}

function showModal({ title = '提示', content, type = 'alert', onConfirm, confirmText = '确定', cancelText = '取消' }) {
    initModalStructure();
    
    const overlay = document.getElementById('customModalOverlay');
    const titleEl = document.getElementById('customModalTitle');
    const bodyEl = document.getElementById('customModalBody');
    const footerEl = document.getElementById('customModalFooter');

    titleEl.textContent = title;
    bodyEl.innerHTML = content; // 支持 HTML 内容

    // 生成按钮
    let buttonsHtml = '';
    if (type === 'confirm') {
        buttonsHtml += `<button class="modal-btn modal-btn-secondary" id="modalCancelBtn">${cancelText}</button>`;
    }
    buttonsHtml += `<button class="modal-btn modal-btn-primary" id="modalConfirmBtn">${confirmText}</button>`;
    
    footerEl.innerHTML = buttonsHtml;

    // 绑定事件
    const confirmBtn = document.getElementById('modalConfirmBtn');
    confirmBtn.replaceWith(confirmBtn.cloneNode(true)); // 清除旧事件
    document.getElementById('modalConfirmBtn').addEventListener('click', () => {
        if (onConfirm) onConfirm();
        closeModal();
    });

    if (type === 'confirm') {
        const cancelBtn = document.getElementById('modalCancelBtn');
        cancelBtn.replaceWith(cancelBtn.cloneNode(true));
        document.getElementById('modalCancelBtn').addEventListener('click', closeModal);
    }

    // 显示
    overlay.classList.add('active');
}

function closeModal() {
    const overlay = document.getElementById('customModalOverlay');
    if (overlay) overlay.classList.remove('active');
}

// 替换原生 alert
window.alert = (msg) => {
    // 识别成功/失败/普通提示
    let title = '提示';
    if (msg.includes('成功')) title = '操作成功';
    if (msg.includes('失败') || msg.includes('错误')) title = '出错了';
    
    // 识别是否包含订单号等复杂信息
    let content = msg.replace(/\n/g, '<br>');
    if (content.includes('订单号')) {
        content = content.replace(/(订单号：.*?)(<br>|$)/, '<span class="modal-highlight">$1</span>$2');
    }
    
    showModal({ title, content, confirmText: '我知道了' });
};

// 提供异步 confirm
window.asyncConfirm = (msg) => {
    return new Promise((resolve) => {
        showModal({
            title: '确认操作',
            content: msg,
            type: 'confirm',
            confirmText: '确认',
            cancelText: '取消',
            onConfirm: () => resolve(true)
        });
    });
};

// --- 全局通用弹窗逻辑 (客服 & 服务列表) ---
// 这些逻辑被所有页面共用 (popup, login, register, forgot, reset)

document.addEventListener('DOMContentLoaded', () => {
    // --- 逻辑调整：如果在登录/注册页点击，则引导到主界面再打开弹窗 ---
    // 注意：注册页 (register.html) 和 忘记密码页 (forgot.html) 也被视为"非主界面"
    const isMainPage = window.location.pathname.includes('popup.html');

    // 绑定联系客服
    document.querySelectorAll('.contact-support').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            if (isMainPage) {
                renderSupportModal();
            } else {
                // 引导到主界面，并带上 action 参数
                window.location.href = 'popup.html?action=support';
            }
        });
    });

    // 绑定其他服务
    document.querySelectorAll('.other-services').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            if (isMainPage) {
                renderServiceListModal();
            } else {
                // 引导到主界面，并带上 action 参数
                window.location.href = 'popup.html?action=services';
            }
        });
    });

    // --- 新增：页面加载时检查 URL 参数 ---
    const urlParams = new URLSearchParams(window.location.search);
    const action = urlParams.get('action');
    
    // 检查是否是刚注册成功，如果是，则自动弹窗
    const isNewRegister = urlParams.get('new_register') === 'true';

    if (action === 'support' || isNewRegister) {
        renderSupportModal();
    } else if (action === 'services') {
        renderServiceListModal();
    }

    // --- 新增：内部跳转时携带参数 ---
    if (window.location.search) {
        document.querySelectorAll('a').forEach(link => {
            const href = link.getAttribute('href');
            if (href && href.endsWith('.html') && !href.startsWith('http')) {
                const connector = href.includes('?') ? '&' : '?';
                link.setAttribute('href', href + connector + window.location.search.substring(1));
            }
        });
    }
});

// 渲染客服弹窗
function renderSupportModal() {
    const modal = document.createElement('div');
    modal.className = 'support-modal';
    modal.innerHTML = `
        <div class="modal-header">
            <h3 style="color: white;">联系客服</h3>
            <button class="modal-close" title="关闭">&times;</button>
        </div>
        <div class="modal-body">
            <textarea class="support-input" placeholder="请描述您遇到的问题..."></textarea>
            <button class="support-submit" disabled>提交</button>
        </div>
    `;
    
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    
    document.body.appendChild(overlay);
    document.body.appendChild(modal);

    const input = modal.querySelector('.support-input');
    const submitBtn = modal.querySelector('.support-submit');
    
    setTimeout(() => input.focus(), 50);
    
    input.addEventListener('input', () => {
        const hasText = input.value.trim().length > 0;
        submitBtn.disabled = !hasText;
        if (hasText) submitBtn.textContent = '提交';
    });
    
    input.addEventListener('keydown', (e) => {
        if (e.ctrlKey && e.key === 'Enter' && !submitBtn.disabled) {
            submitBtn.click();
        }
        if (e.key === 'Escape') closeModal();
    });

    submitBtn.addEventListener('click', async () => {
        const question = input.value.trim();
        if (!question) return;

        submitBtn.disabled = true;
        submitBtn.textContent = '提交中...';

        try {
            const storage = await chrome.storage.local.get(['user']);
            const user = storage.user || {};
            const username = user.username || user.identifier || (user.email ? user.email.split('@')[0] : 'anonymous');

            const payload = {
                username: username,
                content: question,
                role: 'user'
            };

            const API_URL = 'https://nexusproxy.asia/api/chat/send'; 
            
            const res = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            
            if (!res.ok) {
                const errorData = await res.json().catch(() => ({}));
                const msg = errorData.message || `请求失败 (${res.status})`;
                throw new Error(msg);
            }
            
            if (window.showToast) {
                window.showToast('您的问题已提交，客服将在1个工作日内回复'); 
            } else {
                alert('您的问题已提交，客服将在1个工作日内回复');
            }
            
            closeModal();

        } catch (error) {
            console.error('客服提交失败:', error);
            let errorMsg = '提交失败，请检查网络后重试';
            if (error.name === 'TypeError' && error.message.includes('fetch')) {
                errorMsg = '网络连接失败或跨域被拦截，请联系管理员';
            } else if (error.message) {
                errorMsg = `提交失败: ${error.message}`;
            }

            if (window.showToast) {
                window.showToast(errorMsg); 
            } else {
                alert(errorMsg);
            }
            submitBtn.disabled = false;
            submitBtn.textContent = '提交';
        }
    });

    const closeModal = () => {
        modal.style.opacity = '0';
        overlay.style.opacity = '0';
        setTimeout(() => {
            modal.remove();
            overlay.remove();
        }, 200);
    };
    
    const closeBtn = modal.querySelector('.modal-close');
    closeBtn.addEventListener('click', closeModal);
    overlay.addEventListener('click', closeModal);
}

// 渲染服务列表弹窗
function renderServiceListModal() {
    const modal = document.createElement('div');
    modal.className = 'support-modal service-list-modal';
    
    modal.style.padding = '0'; 
    modal.style.overflow = 'hidden';

    modal.innerHTML = `
        <div class="modal-header" style="padding: 16px; border-bottom: 1px solid #eee;">
            <h3 style="margin: 0; font-size: 16px; color: white;">服务列表</h3>
            <button class="modal-close" title="关闭">&times;</button>
        </div>
        
        <div style="padding: 12px 16px; background: #fff3e0; color: #f57c00; font-size: 12px; line-height: 1.4;">
            温馨提示：所有服务账户密码通用，不同服务需要分开续费。
        </div>

        <div class="modal-body" style="padding: 0;">
            <div class="service-item" style="display: flex; align-items: center; padding: 16px; border-bottom: 1px solid #f5f5f5;">
                <div class="service-icon" style="width: 40px; height: 40px; background: #e3f2fd; border-radius: 8px; display: flex; align-items: center; justify-content: center; margin-right: 12px; color: #2196f3; font-size: 20px;">
                    🌐
                </div>
                <div class="service-info" style="flex: 1;">
                    <h4 style="margin: 0 0 4px 0; font-size: 14px; color: #333;">NexusProxy</h4>
                    <p style="margin: 0; font-size: 12px; color: #666; line-height: 1.4;">专业的海外代理服务，助力跨境业务稳定访问。</p>
                </div>
                <button class="open-btn" data-url="https://nexusproxy.asia/" style="
                    background: #673AB7; 
                    color: white; 
                    border: none; 
                    padding: 6px 12px; 
                    border-radius: 4px; 
                    font-size: 12px; 
                    cursor: pointer; 
                    margin-left: 10px;
                    white-space: nowrap;
                ">立即打开</button>
            </div>
        </div>
        
        <div class="modal-footer" style="padding: 16px; text-align: center; border-top: 1px solid #eee;">
             <button class="close-btn" style="
                background: white; 
                border: 1px solid #ddd; 
                color: #666; 
                padding: 8px 24px; 
                border-radius: 4px; 
                cursor: pointer;
                font-size: 13px;
             ">关闭</button>
        </div>
    `;

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    
    document.body.appendChild(overlay);
    document.body.appendChild(modal);

    modal.querySelectorAll('.open-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const url = btn.dataset.url;
            chrome.tabs.create({ url: url });
        });
    });

    const closeModal = () => {
        modal.style.opacity = '0';
        overlay.style.opacity = '0';
        setTimeout(() => {
            modal.remove();
            overlay.remove();
        }, 200);
    };

    modal.querySelector('.modal-close').addEventListener('click', closeModal);
    modal.querySelector('.close-btn').addEventListener('click', closeModal);
    overlay.addEventListener('click', closeModal);
}

// 渲染确认弹窗（用于退出登录等）
function renderConfirmModal({ title, content, confirmText = '确认', cancelText = '取消', onConfirm }) {
    const modal = document.createElement('div');
    modal.className = 'support-modal confirm-modal'; // 复用基础样式 + 确认框特有样式
    
    // 绿色顶栏 + 白色文字
    modal.innerHTML = `
        <div class="modal-header">
            <h3 style="color: white; font-size: 16px; margin: 0;">${title}</h3>
            <button class="modal-close" title="关闭">&times;</button>
        </div>
        <div class="modal-body" style="padding: 24px 20px; text-align: center;">
            <p style="margin: 0 0 24px 0; font-size: 15px; color: #333; line-height: 1.5;">${content}</p>
            <div style="display: flex; gap: 12px; justify-content: center;">
                <button class="confirm-btn cancel" style="
                    flex: 1;
                    padding: 10px;
                    border: 1px solid #ddd;
                    background: white;
                    color: #666;
                    border-radius: 6px;
                    cursor: pointer;
                    font-size: 14px;
                ">${cancelText}</button>
                <button class="confirm-btn confirm" style="
                    flex: 1;
                    padding: 10px;
                    border: none;
                    background: #4CAF50;
                    color: white;
                    border-radius: 6px;
                    cursor: pointer;
                    font-size: 14px;
                ">${confirmText}</button>
            </div>
        </div>
    `;
    
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay'; // 复用现有的遮罩样式 (fixed + center)
    
    document.body.appendChild(overlay);
    document.body.appendChild(modal);

    const closeModal = () => {
        modal.style.opacity = '0';
        overlay.style.opacity = '0';
        setTimeout(() => {
            modal.remove();
            overlay.remove();
        }, 200);
    };

    // 绑定事件
    modal.querySelector('.modal-close').addEventListener('click', closeModal);
    modal.querySelector('.cancel').addEventListener('click', closeModal);
    overlay.addEventListener('click', closeModal); // 点击遮罩关闭

    modal.querySelector('.confirm').addEventListener('click', () => {
        if (onConfirm) onConfirm();
        closeModal();
    });
}

// 暴露给全局调用
window.showConfirmModal = renderConfirmModal;
