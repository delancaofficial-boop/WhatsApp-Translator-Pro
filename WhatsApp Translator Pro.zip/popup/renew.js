// renew.js - 处理续费页面的交互

// 配置 API 基础地址
const API_BASE_URL = 'https://nexusproxy.asia/api'; 

document.addEventListener('DOMContentLoaded', () => {
    const planItems = document.querySelectorAll('.plan-item');
    const payBtn = document.getElementById('payBtn');
    const backBtn = document.getElementById('backBtn');
    const usernameEl = document.getElementById('username');
    const expiryDateEl = document.getElementById('expiryDate');

    // 1. 初始化用户信息
    chrome.storage.local.get(['user'], (res) => {
        const user = res.user;
        if (user) {
            // 优先显示邮箱或号码 (identifier)
            usernameEl.textContent = user.identifier || user.email || user.username || '未登录';
            const rawExpiry = user.expiry_date || user.expire_at || '未开通';
            expiryDateEl.textContent = rawExpiry === '永久' ? '永久' : rawExpiry;
        }
    });

    // 2. 检查 QRCode 库能否正常加载
    if (typeof QRCode === 'undefined') {
        console.error('QRCode library not loaded!');
        window.alert('系统错误: 二维码组件加载失败，请联系客服或重新安装插件。');
        if (payBtn) payBtn.disabled = true;
    }

    // 3. 返回按钮
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            window.location.href = 'popup.html';
        });
    }

    // 4. 方案选择交互
    planItems.forEach(item => {
        item.addEventListener('click', () => {
            planItems.forEach(i => i.classList.remove('active'));
            item.classList.add('active');
        });
    });

    // 5. 价格与标签映射 (用于订单创建)
    const PLAN_CONFIG = {
        '1': { price: '30.00', label: '1个月', backendPeriod: '1 month', localMonths: 1 },
        '3': { price: '75.00', label: '3个月', backendPeriod: '3 months', localMonths: 3 },
        '12': { price: '210.00', label: '12个月', backendPeriod: '1 year', localMonths: 12 },
        '100': { price: '780.00', label: '永久', backendPeriod: 'forever', localMonths: 100 }
    };

    // 6. 支付弹窗处理
    const modal = document.getElementById('paymentModal');
    const closeModalText = document.getElementById('closeModalText');
    const qrcodeContainer = document.getElementById('qrcode');
    const modalTitle = document.getElementById('modalTitle');
    const modalPrice = document.getElementById('modalPrice');
    const qrTitle = document.getElementById('qrTitle');
    
    let pollTimer = null;
    let isPolling = false;

    if (closeModalText) {
        closeModalText.addEventListener('click', () => {
            modal.style.display = 'none';
            modal.classList.remove('active');
            qrcodeContainer.innerHTML = '';
            payBtn.disabled = false;
            payBtn.innerHTML = '立即续费<span class="btn-subtext">安全支付 · 自动到账</span>';
            
            // 停止轮询
            if (pollTimer) {
                clearInterval(pollTimer);
                pollTimer = null;
            }
            isPolling = false;
        });
    }

    // 7. 立即续费点击
    payBtn.addEventListener('click', async () => {
        const activePlan = document.querySelector('.plan-item.active');
        if (!activePlan) return;

        const months = activePlan.getAttribute('data-months');
        const config = PLAN_CONFIG[months];
        const productName = "WhatsApp 翻译插件"; // 修正产品名

        payBtn.disabled = true;
        payBtn.textContent = '正在创建订单...';

        chrome.storage.local.get(['user'], async (res) => {
            const user = res.user;
            const username = user?.identifier || user?.username || user?.email;
            
            if (!username) {
                window.alert('请先登录！');
                window.location.href = 'login.html';
                return;
            }

            // 记录支付前的有效期，用于轮询比对
            const initialExpiry = user.expiry_date || user.expire_at || '1970-01-01';

            try {
                // 1. 调用支付接口
                const payload = {
                    username: username,
                    region: productName,
                    period: config.backendPeriod
                };
                
                console.log('创建订单 Payload:', payload);

                const createRes = await fetch(`${API_BASE_URL}/pay/create`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });

                const createResult = await createRes.json();
                console.log('订单创建结果:', createResult);

                if (createRes.ok && createResult.success && createResult.pay_url) {
                    // 2. 提取二维码链接
                    // pay_url 示例: https://nexusproxy.asia/pay/qrcode?code=https://qr.alipay.com/...&order_id=...
                    let codeUrl = '';
                    try {
                        const urlObj = new URL(createResult.pay_url);
                        codeUrl = urlObj.searchParams.get('code');
                    } catch (e) {
                        console.error('解析 pay_url 失败:', e);
                    }

                    if (!codeUrl) {
                        throw new Error('无法获取支付二维码，请重试');
                    }

                    // 3. 展示弹窗并生成二维码
                    modalTitle.textContent = `PRO版 ${config.label}`;
                    qrTitle.textContent = `扫码支付 ¥${config.price}`;
                    modalPrice.textContent = `¥${config.price}`;
                    
                    qrcodeContainer.innerHTML = ''; // 清空旧码
                    // 使用低容错率(L)以容纳更长的 URL，避免 "code length overflow" 错误
                    new QRCode(qrcodeContainer, {
                        text: codeUrl,
                        width: 140,
                        height: 140,
                        colorDark : "#000000",
                        colorLight : "#ffffff",
                        correctLevel : QRCode.CorrectLevel.L
                    });

                    modal.style.display = 'flex';
                    // 强制重绘后添加 active 类以触发动画
                    setTimeout(() => modal.classList.add('active'), 10);

                    // 4. 开始轮询查单 (通过检查用户有效期变化)
                    startPolling(username, initialExpiry);

                } else {
                    throw new Error(createResult.message || '订单创建失败');
                }

            } catch (error) {
                console.error('支付流程出错:', error);
                window.alert('操作失败: ' + error.message);
                payBtn.disabled = false;
                payBtn.innerHTML = '立即续费<span class="btn-subtext">安全支付 · 自动到账</span>';
            }
        });
    });

    // 轮询检查支付结果
    function startPolling(username, initialExpiry) {
        if (isPolling) return;
        isPolling = true;
        
        let attempts = 0;
        const maxAttempts = 60; // 3秒一次，共3分钟
        
        pollTimer = setInterval(async () => {
            attempts++;
            if (attempts > maxAttempts) {
                clearInterval(pollTimer);
                isPolling = false;
                window.alert('支付超时，请重新发起支付或联系客服。');
                return;
            }

            try {
                // 查询用户信息
                const res = await fetch(`${API_BASE_URL}/user/info?username=${encodeURIComponent(username)}`);
                if (res.ok) {
                    const data = await res.json();
                    if (data.success && data.data) {
                        const newExpiry = data.data.expiry_date || data.data.expire_at;
                        
                        // 检查有效期是否更新
                        if (checkExpiryUpdated(initialExpiry, newExpiry)) {
                            clearInterval(pollTimer);
                            isPolling = false;
                            
                            // 更新本地存储
                            chrome.storage.local.get(['user'], (localRes) => {
                                const newUser = { ...localRes.user, ...data.data };
                                chrome.storage.local.set({ user: newUser }, () => {
                                    // 支付成功反馈
                                    modal.classList.remove('active');
                                    setTimeout(() => modal.style.display = 'none', 200);
                                    
                                    window.alert(`支付成功！\n会员已续费至：${newExpiry}`);
                                    
                                    // 通知其他页面刷新
                                    chrome.runtime.sendMessage({ action: 'refreshUser' });
                                    
                                    // 刷新当前页或跳转
                                    setTimeout(() => window.location.href = 'popup.html', 1000);
                                });
                            });
                        }
                    }
                }
            } catch (e) {
                console.warn('轮询出错:', e);
            }
        }, 3000);
    }

    // 辅助函数：比较日期是否更新
    function checkExpiryUpdated(oldDate, newDate) {
        if (!newDate) return false;
        if (newDate === '永久') return oldDate !== '永久';
        if (oldDate === '永久') return false; // 原本就是永久，理论上不会进这里，除非续费更高级的服务？但目前永久是最高
        if (!oldDate || oldDate === '未开通') return true;
        
        // 简单字符串比较 YYYY-MM-DD
        return newDate > oldDate;
    }
});
