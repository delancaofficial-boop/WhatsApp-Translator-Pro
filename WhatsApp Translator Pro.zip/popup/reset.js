// reset.js - 处理重置密码逻辑

const API_BASE_URL = 'https://nexusproxy.asia/api';

document.addEventListener('DOMContentLoaded', () => {
    const resetForm = document.getElementById('resetForm');
    const newPasswordInput = document.getElementById('newPassword');
    const confirmPasswordInput = document.getElementById('confirmPassword');
    const submitBtn = document.getElementById('submitBtn');
    const msgArea = document.getElementById('msgArea');

    // 解析 URL 参数
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');
    const uid = urlParams.get('uid');

    if (!token || !uid) {
        showMsg('无效的重置链接，缺少必要参数', 'error');
        submitBtn.disabled = true;
    }

    function showMsg(text, type) {
        msgArea.textContent = text;
        msgArea.className = `msg-area msg-${type}`;
    }

    function clearMsg() {
        msgArea.textContent = '';
        msgArea.className = 'msg-area';
    }

    // 提交逻辑
    resetForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const newPassword = newPasswordInput.value;
        const confirmPassword = confirmPasswordInput.value;

        if (newPassword.length < 8) {
            showMsg('密码长度不能少于8位', 'error');
            return;
        }

        if (newPassword !== confirmPassword) {
            showMsg('两次输入的密码不一致', 'error');
            return;
        }

        submitBtn.disabled = true;
        submitBtn.textContent = '提交中...';
        clearMsg();

        try {
            const response = await fetch(`${API_BASE_URL}/user/reset-password`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    token: token,
                    uid: uid,
                    newPassword: newPassword
                })
            });

            const result = await response.json();

            if (response.ok && result.success) {
                showMsg('密码修改成功！即将跳转登录...', 'success');
                // 弹窗提示更明显
                window.alert('密码修改成功！请使用新密码登录。');
                setTimeout(() => {
                    window.location.href = 'login.html';
                }, 2000);
            } else {
                showMsg(result.message || '重置失败，链接可能已失效', 'error');
                submitBtn.disabled = false;
                submitBtn.textContent = '确认重置';
            }
        } catch (error) {
            console.error('重置密码请求失败:', error);
            showMsg('服务器异常，请重试', 'error');
            submitBtn.disabled = false;
            submitBtn.textContent = '确认重置';
        }
    });
});
