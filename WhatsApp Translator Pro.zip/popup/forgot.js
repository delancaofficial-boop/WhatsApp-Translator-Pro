// forgot.js - 处理找回密码逻辑 (验证码模式)

const API_BASE_URL = 'https://nexusproxy.asia/api';

document.addEventListener('DOMContentLoaded', () => {
    // --- 新增：页面状态恢复与输入缓存 ---
    const currentPage = window.location.pathname.split('/').pop();
    
    chrome.storage.local.get(['cachedInputs'], (res) => {
        if (res.cachedInputs && res.cachedInputs.forgotEmail) {
            document.getElementById('email').value = res.cachedInputs.forgotEmail;
        }
        // 记录当前页面
        chrome.storage.local.set({ lastPage: currentPage });
    });

    // 监听输入并缓存
    document.getElementById('email').addEventListener('input', (e) => {
        chrome.storage.local.get(['cachedInputs'], (res) => {
            const cached = res.cachedInputs || {};
            cached.forgotEmail = e.target.value;
            chrome.storage.local.set({ cachedInputs: cached });
        });
    });

    // 监听返回登录按钮，清除持久化状态
    const backToLogin = document.querySelector('.back-link a');
    if (backToLogin) {
        backToLogin.addEventListener('click', () => {
            chrome.storage.local.remove(['lastPage']);
        });
    }

    // --- 原有逻辑开始 ---
    const step1 = document.getElementById('step1');
    const step2 = document.getElementById('step2');
    
    const emailInput = document.getElementById('email');
    const sendCodeBtn = document.getElementById('sendCodeBtn');
    
    const verifyCodeInput = document.getElementById('verifyCode');
    const newPasswordInput = document.getElementById('newPassword');
    const confirmPasswordInput = document.getElementById('confirmPassword');
    const resetBtn = document.getElementById('resetBtn');
    
    const msgArea = document.getElementById('msgArea');

    // 1. 邮箱格式校验
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    emailInput.addEventListener('blur', () => {
        const email = emailInput.value.trim();
        if (email && !validateEmail(email)) {
            showMsg('请输入有效的邮箱地址', 'error');
        } else {
            clearMsg();
        }
    });

    function showMsg(text, type) {
        msgArea.textContent = text;
        msgArea.className = `msg-area msg-${type}`;
    }

    function clearMsg() {
        msgArea.textContent = '';
        msgArea.className = 'msg-area';
    }

    // 2. 发送验证码逻辑
    sendCodeBtn.addEventListener('click', async () => {
        const email = emailInput.value.trim();

        if (!email) {
            showMsg('请填写绑定邮箱', 'error');
            return;
        }

        if (!validateEmail(email)) {
            showMsg('请输入有效的邮箱地址', 'error');
            return;
        }

        // 按钮状态切换
        sendCodeBtn.disabled = true;
        sendCodeBtn.textContent = '发送中...';
        clearMsg();

        try {
            const response = await fetch(`${API_BASE_URL}/password/send-reset-code`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ email })
            });

            // 增加健壮性检查
            const responseText = await response.text();
            let result;
            try {
                result = JSON.parse(responseText);
            } catch (e) {
                console.error('非JSON响应:', responseText);
                showMsg('服务器维护中，请稍后重试', 'error');
                throw new Error('Invalid JSON response');
            }

            if (response.ok && result.success) {
                showMsg('验证码已发送，请查收', 'success');
                step1.style.display = 'none';
                step2.style.display = 'block';
            } else {
                showMsg(result.message || '该邮箱未注册', 'error');
                sendCodeBtn.disabled = false;
                sendCodeBtn.textContent = '发送验证码';
            }
        } catch (error) {
            console.error('发送验证码失败:', error);
            if (error.message !== 'Invalid JSON response') {
                showMsg('服务器异常，请重试', 'error');
            }
            sendCodeBtn.disabled = false;
            sendCodeBtn.textContent = '发送验证码';
        }
    });

    // 3. 确认重置逻辑
    document.getElementById('forgotForm').addEventListener('submit', async (e) => {
        e.preventDefault();

        // 确保是第二步提交
        if (step2.style.display === 'none') return;

        const email = emailInput.value.trim();
        const code = verifyCodeInput.value.trim();
        const newPassword = newPasswordInput.value.trim();
        const confirmPassword = confirmPasswordInput.value;

        if (!code) {
            showMsg('请输入验证码', 'error');
            return;
        }

        if (newPassword.length < 8) {
            showMsg('新密码至少需要8位', 'error');
            return;
        }

        if (newPassword !== confirmPassword) {
            showMsg('两次输入的密码不一致', 'error');
            return;
        }

        resetBtn.disabled = true;
        resetBtn.textContent = '重置中...';
        clearMsg();

        try {
            const response = await fetch(`${API_BASE_URL}/password/reset`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email: email,
                    code: code,
                    new_password: newPassword
                })
            });

            const result = await response.json();

            if (response.ok && result.success) {
                showMsg('密码重置成功！即将跳转...', 'success');
                window.alert('密码修改成功！请使用新密码登录。');
                setTimeout(() => {
                    window.location.href = 'login.html';
                }, 1500);
            } else {
                showMsg(result.message || '验证码无效或已过期', 'error');
                resetBtn.disabled = false;
                resetBtn.textContent = '确认重置';
            }
        } catch (error) {
            console.error('重置密码失败:', error);
            showMsg('网络错误，请稍后重试', 'error');
            resetBtn.disabled = false;
            resetBtn.textContent = '确认重置';
        }
    });
});
