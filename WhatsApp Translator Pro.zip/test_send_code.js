const https = require('https');

const email = 'test_user_001@gmail.com'; // 使用一个测试邮箱
const data = JSON.stringify({
  email: email
});

const options = {
  hostname: 'nexusproxy.asia',
  path: '/api/register/send-code',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(data),
    // 模拟 Origin，虽然 Node.js 不会像浏览器那样强制 CORS，但可以看看后端反应
    'Origin': 'chrome-extension://knldjmfmopnpolahpmmgbagdohdnhkik' 
  }
};

console.log('Sending request to:', `https://${options.hostname}${options.path}`);

const req = https.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    console.log('Status:', res.statusCode);
    console.log('Headers:', JSON.stringify(res.headers, null, 2));
    console.log('Body:', body);
  });
});

req.on('error', (e) => {
  console.error('Request Error:', e);
});

req.write(data);
req.end();