const https = require('https');

const data = JSON.stringify({
  username: 'test_user',
  region: 'Whatsapp',
  period: '1个月'
});

const options = {
  hostname: 'nexusproxy.asia',
  path: '/api/pay/create',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(data)
  }
};

const req = https.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    console.log('Status:', res.statusCode);
    console.log('Body:', body);
  });
});

req.on('error', (e) => {
  console.error(e);
});

req.write(data);
req.end();