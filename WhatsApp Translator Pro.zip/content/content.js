// content.js
console.log('WhatsApp Translator Pro: Content Script Active');

let settings = {};
let observer = null;
let intersectionObserver = null; // 用于懒加载翻译
let detectedContactLang = null; // 存储当前联系人检测到的语言

// 1. 初始化配置
chrome.storage.local.get(null, (result) => {
  settings = result;
  console.log('Initial settings loaded:', settings);
  initIntersectionObserver(); // 初始化交叉观察器
  startObservation();
  setupInputListener();
  injectStyles(); // 注入图标样式
});

// 初始化交叉观察器 (懒加载逻辑)
function initIntersectionObserver() {
    if (intersectionObserver) intersectionObserver.disconnect();
    
    intersectionObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const el = entry.target;
                // 只有在开启自动翻译时才在进入视口时触发
                if (settings.translationStatus && settings.autoTranslate) {
                    console.log('Element entered viewport, triggering translation:', el.innerText.substring(0, 20));
                    triggerTranslationForElement(el);
                }
                // 触发后停止观察该元素，避免重复翻译
                intersectionObserver.unobserve(el);
            }
        });
    }, { 
        threshold: 0.1,
        rootMargin: '50px' // 提前 50px 开始加载，提升体验
    });
}

// 注入图标样式
function injectStyles() {
    if (document.getElementById('wa-trans-styles')) return;
    const style = document.createElement('style');
    style.id = 'wa-trans-styles';
    style.innerHTML = `
        .wa-translate-icon-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 20px;
            height: 20px;
            cursor: pointer;
            z-index: 10;
            background: #f0f0f0;
            border-radius: 50%;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 1px 2px rgba(0,0,0,0.1);
            margin-right: 8px;
            vertical-align: middle;
            border: none;
            padding: 0;
            outline: none;
            position: relative;
        }
        
        .wa-translate-icon-btn:hover {
            background: #009688 !important;
            transform: scale(1.1);
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        
        .wa-translate-icon-btn:active {
            transform: scale(0.95);
        }

        .wa-translate-icon-btn svg {
            width: 14px;
            height: 14px;
            fill: #009688;
            transition: fill 0.2s;
        }
        
        .wa-translate-icon-btn:hover svg {
            fill: white !important;
        }

        /* 加载动画 */
        @keyframes wa-rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        .wa-translate-loading svg {
            animation: wa-rotate 1s linear infinite;
        }

        /* 适配消息气泡元数据区 */
        [data-testid="msg-meta"] {
            display: flex !important;
            align-items: center !important;
            flex-direction: row-reverse !important;
            position: relative !important;
            z-index: 5 !important;
        }
        
        /* 确保消息气泡有相对定位，防止图标乱跑 */
        [data-testid="msg-container"] {
            position: relative !important;
        }

        /* Tooltip */
        .wa-translate-icon-btn::after {
            content: attr(data-title);
            position: absolute;
            bottom: 130%;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0,0,0,0.85);
            color: white;
            padding: 5px 10px;
            border-radius: 6px;
            font-size: 11px;
            white-space: nowrap;
            opacity: 0;
            visibility: hidden;
            transition: all 0.2s;
            pointer-events: none;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }
        
        .wa-translate-icon-btn:hover::after {
            opacity: 1;
            visibility: visible;
            bottom: 140%;
        }
    `;
    document.head.appendChild(style);
}

// 2. 监听设置更新
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'SETTINGS_UPDATED') {
    settings = request.settings;
    console.log('Settings synchronized:', settings);
    initIntersectionObserver(); // 重新初始化观察器
    processExistingMessages();
  }
});

// 3. 核心监听器：监控消息变化
function startObservation() {
  if (observer) observer.disconnect();

  let timeout;
  observer = new MutationObserver((mutations) => {
    // 即使关闭自动翻译，也要运行以添加图标
    if (!settings.translationStatus) return;
    
    clearTimeout(timeout);
    timeout = setTimeout(() => {
      processExistingMessages();
    }, 300); // 缩短防抖时间，提高响应速度
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // 初始加载优化：进行多次轮询，确保捕捉到异步加载的第一批消息
  console.log('Starting initial message polling...');
  let pollCount = 0;
  const initialPoll = setInterval(() => {
      processExistingMessages();
      pollCount++;
      if (pollCount > 10) clearInterval(initialPoll); // 轮询 5 秒 (500ms * 10)
  }, 500);
}

// 注入快捷回复栏
function checkAndInjectQuickReplyBar() {
    // 如果功能未开启或翻译功能未开启，移除已存在的栏
    if (!settings.translationStatus) {
        const existingBar = document.getElementById('wa-quick-reply-bar');
        if (existingBar) existingBar.remove();
        return;
    }

    // 查找 footer (输入框所在的容器)
    const footer = document.querySelector('footer');
    if (!footer) return;

    // 如果已经存在，直接返回
    if (document.getElementById('wa-quick-reply-bar')) return;

    // 创建快捷栏
    const bar = document.createElement('div');
    bar.id = 'wa-quick-reply-bar';
    
    // 定义快捷语
    const quickReplies = [
        { label: "你好", text: "你好" },
        { label: "问价", text: "请问这个多少钱？" },
        { label: "起订量", text: "最小起订量是多少？" },
        { label: "发货中国", text: "可以发货到中国吗？" },
        { label: "询问质量", text: "质量怎么样？" },
        { label: "谢谢", text: "谢谢" }
    ];

    quickReplies.forEach(item => {
        const btn = document.createElement('button');
        btn.className = 'wa-quick-reply-btn';
        btn.innerText = item.label;
        btn.title = item.text; // 鼠标悬停显示完整文本
        
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            
            // 找到输入框
            const inputField = document.querySelector('[data-testid="conversation-compose-box-input"]') || 
                               document.querySelector('footer div[contenteditable="true"]');
            
            if (inputField) {
                // 1. 聚焦并填入原文
                inputField.focus();
                
                // 先清空可能存在的文本 (可选，取决于是否希望追加) -> 用户需求是"填充"，通常是新的开始
                // inputField.innerHTML = ''; 
                // 为了保险，模拟选中所有内容然后替换，这样如果用户之前有输入，会被覆盖
                document.execCommand('selectAll', false, null);
                document.execCommand('insertText', false, item.text);
                
                // 2. 触发翻译并发送
                // 稍微延迟一下确保 DOM 更新
                setTimeout(() => {
                   handleQuickTranslate(inputField, item.text, true);
                }, 50);
            }
        });
        
        bar.appendChild(btn);
    });

    // 插入到 footer 的最前面
    // WhatsApp footer 通常是 flex-direction: column (包含引用消息区等) 或 row
    // 我们希望它在最上面
    footer.style.flexDirection = 'column'; // 强制垂直布局以容纳新的一行
    footer.insertBefore(bar, footer.firstChild);
}

// 4. 处理消息逻辑 (重构：添加图标与按需观察)
function processExistingMessages() {
  if (!settings.translationStatus) return;

  const msgElements = document.querySelectorAll('.selectable-text span, span.copyable-text span');
  
  msgElements.forEach((el) => {
    if (el.innerText.length < 2 || el.querySelector('img') || el.closest('[data-testid="msg-meta"]')) return;

    const originalText = el.innerText.trim();
    const textHash = btoa(unescape(encodeURIComponent(originalText))).substring(0, 16);
    const transId = `trans-${textHash}`;

    if (document.getElementById(transId)) return;

    // --- 智能翻译过滤逻辑 ---
    const chineseMatches = originalText.match(/[\u4e00-\u9fa5]/g);
    const chineseCount = chineseMatches ? chineseMatches.length : 0;
    const totalLength = originalText.replace(/\s/g, '').length;
    if (totalLength === 0) return;
    const foreignRatio = (totalLength - chineseCount) / totalLength;

    // 只有外文占比高才处理
    if (foreignRatio <= 0.7) return;

    // 1. 添加手动翻译图标 (如果尚未添加)
    addTranslateIcon(el, transId);

    // 2. 如果开启了自动翻译，则加入懒加载观察列表
    if (settings.autoTranslate) {
        intersectionObserver.observe(el);
    }
  });
}

// 添加手动翻译图标
function addTranslateIcon(el, transId) {
    if (el.dataset.hasIcon === 'true') return;
    
    // 找到消息气泡的元数据区域 (包含时间戳的地方)
    const bubble = el.closest('[data-testid="msg-container"]') || el.closest('.copyable-text') || el.parentElement;
    if (!bubble) return;
    
    const metaArea = bubble.querySelector('[data-testid="msg-meta"]');
    
    // 如果找不到元数据区，或者元数据区被隐藏，则尝试追加到文本后面
    // 方案 A：如果能找到 metaArea，则插入到时间戳旁边 (保持原逻辑)
    if (metaArea) {
        el.dataset.hasIcon = 'true';
        const iconBtn = createIconBtn(el, transId);
        // 插入到 metaArea 的最前面 (flex row-reverse 后会显示在最右边/时间戳左边)
        metaArea.insertBefore(iconBtn, metaArea.firstChild);
    } 
    // 方案 B：如果找不到 metaArea，创建一个独立的 inline-block 容器放在文本后面
    else {
        el.dataset.hasIcon = 'true';
        const iconBtn = createIconBtn(el, transId);
        // 修改样式使其内联显示
        iconBtn.style.position = 'relative';
        iconBtn.style.display = 'inline-flex';
        iconBtn.style.marginLeft = '8px';
        iconBtn.style.verticalAlign = 'middle';
        
        // 插入到文本节点后面
        el.insertAdjacentElement('afterend', iconBtn);
    }
}

// 辅助函数：创建图标按钮
function createIconBtn(el, transId) {
    const iconBtn = document.createElement('button');
    iconBtn.className = 'wa-translate-icon-btn';
    iconBtn.setAttribute('data-title', '翻译');
    // 使用 "译" 字图标 (SVG 绘制)
    iconBtn.innerHTML = `
        <svg viewBox="0 0 24 24">
            <path d="M12.87 15.07l-2.54-2.51.03-.03c1.74-1.94 2.98-4.17 3.71-6.53H17V4h-7V2H8v2H1v1.99h11.17C11.5 7.92 10.44 9.75 9 11.35 8.07 10.32 7.3 9.19 6.69 8h-2c.73 1.63 1.73 3.17 2.98 4.56l-5.09 5.02L4 19l5-5 3.11 3.11.76-2.04zM18.5 10h-2L12 22h2l1.12-3h4.75L21 22h2l-4.5-12zm-2.62 7l1.62-4.33L19.12 17h-3.24z"/>
        </svg>
    `;

    iconBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        // 切换为加载状态
        iconBtn.classList.add('wa-translate-loading');
        iconBtn.style.pointerEvents = 'none';

        triggerTranslationForElement(el, transId).then(() => {
            iconBtn.style.display = 'none'; // 翻译后隐藏
        }).catch((err) => {
            console.error('Translation failed:', err);
            // 如果是 context invalidated，提示刷新
            if (err && err.message && err.message.includes('invalidated')) {
                showToast('插件已更新，请刷新页面');
            } else if (err && err.message) {
                showToast(`翻译失败: ${err.message}`);
            } else {
                showToast('翻译失败，请检查网络或会员状态');
            }
            iconBtn.classList.remove('wa-translate-loading');
            iconBtn.style.pointerEvents = 'auto';
        });
    });
    
    return iconBtn;
}

// 触发翻译的核心逻辑 (改为返回 Promise 以便处理 UI 状态)
function triggerTranslationForElement(el, transId = null) {
    return new Promise((resolve, reject) => {
        if (el.dataset.translating === 'true') return reject();
        
        // 检查扩展连接
        if (!chrome.runtime?.id) {
            return reject(new Error('Extension context invalidated'));
        }

        const originalText = el.innerText.trim();
        if (!transId) {
            const textHash = btoa(unescape(encodeURIComponent(originalText))).substring(0, 16);
            transId = `trans-${textHash}`;
        }

        if (document.getElementById(transId)) return resolve();

        el.dataset.translating = 'true';
        
        let targetLanguage = settings.sourceLang || 'zh-CN';

        try {
            chrome.runtime.sendMessage({
                type: 'TRANSLATE',
                text: originalText,
                targetLang: targetLanguage,
                engine: settings.engine || 'google'
            }, (response) => {
                el.dataset.translating = 'false';
                
                if (chrome.runtime.lastError) {
                    console.error('Runtime error during translation:', chrome.runtime.lastError);
                    return reject(new Error(chrome.runtime.lastError.message));
                }
                
                if (response && response.success) {
                    renderTranslation(el, response.data, transId);
                    resolve();
                } else {
                    const errorMsg = response?.error || 'API Error';
                    console.error('Translation response error:', errorMsg);
                    reject(new Error(errorMsg));
                }
            });
        } catch (e) {
            el.dataset.translating = 'false';
            console.error('Exception in triggerTranslationForElement:', e);
            reject(e);
        }
    });
}

// 5. 渲染翻译结果 (保持之前优化的分行+无背景样式)
function renderTranslation(targetEl, text, id) {
  if (document.getElementById(id)) return;

  const transDiv = document.createElement('div');
  transDiv.id = id;
  transDiv.className = 'wa-trans-bubble';
  transDiv.innerText = text;
  
  transDiv.setAttribute('style', `
    display: block !important;
    clear: both !important;
    background-color: transparent !important;
    color: #6a1b9a !important;
    padding: 0 !important;
    margin-top: 8px !important;
    font-size: 13px !important;
    line-height: 1.5 !important;
    word-break: break-word !important;
    max-width: 100% !important;
    box-sizing: border-box !important;
    box-shadow: none !important;
    border: none !important;
    animation: waSlideIn 0.3s ease-out !important;
  `);

  const messageContainer = 
    targetEl.closest('.copyable-text') || 
    targetEl.closest('div[data-pre-plain-text]') || 
    targetEl.parentElement;
  
  if (messageContainer) {
    if (targetEl.parentNode === messageContainer) {
        targetEl.insertAdjacentElement('afterend', transDiv);
    } else {
        messageContainer.appendChild(transDiv);
    }
  }
}

// 6. 输入框监听：实现“译完即发”或快捷键翻译
function setupInputListener() {
  // --- 视觉提示观察器 (仅提示正在翻译) ---
  const uiObserver = new MutationObserver(() => {
    const isEnterMode = settings.quickTranslate && settings.quickKey === 'enter';
    if (!isEnterMode || !settings.translationStatus) return;

    const inputField = document.querySelector('[data-testid="conversation-compose-box-input"]') || 
                       document.querySelector('footer div[contenteditable="true"]');
    if (!inputField) return;

    const sendBtn = document.querySelector('button span[data-icon="send"]')?.closest('button') || 
                    document.querySelector('button[aria-label="发送"]') ||
                    document.querySelector('button[aria-label="Send"]');

    if (sendBtn) {
      if (inputField.dataset.isTranslating === 'true') {
        sendBtn.style.opacity = '0.4';
        sendBtn.title = "正在翻译中...";
        sendBtn.style.pointerEvents = 'none';
      } else {
        sendBtn.style.opacity = '1';
        sendBtn.title = "";
        sendBtn.style.pointerEvents = 'auto';
      }
    }
  });

  uiObserver.observe(document.body, { childList: true, subtree: true });

  // --- 核心逻辑：回车触发翻译并发送 ---
  document.addEventListener('keydown', (e) => {
    if (!settings.translationStatus) return;

    // 1. 全局查找输入框 (不依赖 e.target，防止光标丢失或未聚焦时无法获取)
    const inputField = document.querySelector('[data-testid="conversation-compose-box-input"]') || 
                       document.querySelector('footer div[contenteditable="true"]');
    
    // 如果连输入框都找不到，或者事件触发源不在 footer 区域内，则忽略
    // 但为了确保“无需选中”也能触发，只要找到了 inputField 且按下了 Enter，就尝试处理
    if (!inputField) return;

    // 2. 拦截 Enter (非组合键)
    if (e.key === 'Enter' && !e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey) {
       if (e.isAutoSend) return; // 放行插件触发的发送

       if (settings.quickTranslate && settings.quickKey === 'enter') {
          // 步骤 A：自动执行全选 (用户要求的额外保障步骤)
          // 即使我们已经能通过 innerText 获取，先选中一下能确保 WhatsApp 的内部状态被激活
          const selection = window.getSelection();
          const range = document.createRange();
          range.selectNodeContents(inputField);
          selection.removeAllRanges();
          selection.addRange(range);

          // 步骤 B：获取全量文本
          const fullText = (inputField.innerText || inputField.textContent || "").trim();
          
          if (fullText) {
             // 立即同步拦截 WhatsApp 发送
             e.preventDefault();
             e.stopPropagation();
             e.stopImmediatePropagation();

             if (inputField.dataset.isTranslating === 'true') return false;
             
             console.log('Enter pressed. Auto-selected text and translating:', fullText.substring(0, 20));
             // 强制传递全量文本
             handleQuickTranslate(inputField, fullText, true); 
             return false;
          }
       }
    }
  }, true);
}

// 监听来自 Background 的快捷键命令
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'TRIGGER_QUICK_TRANSLATE') {
    if (settings.quickTranslate && settings.quickKey === 'enter') {
        console.log('Shortcut ignored: Enter-to-translate mode is active.');
        return;
    }

    console.log('Shortcut triggered!');
    
    // 1. 准确定位输入框 (优先使用 data-testid)
    const inputField = document.querySelector('[data-testid="conversation-compose-box-input"]') || 
                       document.querySelector('footer div[contenteditable="true"]');

    if (inputField) {
      // 步骤 A：自动执行全选 (快捷键触发时的额外保障)
      inputField.focus();
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(inputField);
      selection.removeAllRanges();
      selection.addRange(range);

      // 步骤 B：获取全量文本 (不再依赖选中)
      const fullText = (inputField.innerText || inputField.textContent || "").trim();
      if (fullText) {
        console.log('Shortcut triggered. Auto-selected text:', fullText.substring(0, 20));
        handleQuickTranslate(inputField, fullText, false); 
      } else {
        console.log('Input is empty, nothing to translate.');
      }
    } else {
      console.warn('Could not find input field.');
    }
  }
});

// 辅助函数：恢复输入框状态 (提前定义，防止提升问题)
function resetInputState(inputField, originalContent) {
    if (!inputField) return;
    
    // 恢复内容
    inputField.innerHTML = originalContent;
    inputField.dataset.isTranslating = 'false';
    inputField.style.opacity = '1';
    inputField.style.pointerEvents = 'auto';
    
    // 恢复占位符提示 (如果有)
    const placeholder = inputField.parentElement.querySelector('.place-holder');
    if (placeholder) placeholder.style.display = inputField.innerText.trim() ? 'none' : 'block';

    inputField.focus();
}

// 抽离出来的通用翻译处理函数
function handleQuickTranslate(inputField, text, autoSend) {
  if (inputField.dataset.isTranslating === 'true') return;
  
  // 1. 设置状态锁与 UI 锁定
  inputField.dataset.isTranslating = 'true';
  const originalContent = inputField.innerHTML; 
  
  // 核心：直接使用传入的 text (参数 text 已经是全量内容)
  // 如果参数为空 (例如快捷键触发时未正确传参)，则兜底读取 innerText
  const contentToTranslate = text || (inputField.innerText || inputField.textContent || "").trim();
  
  if (!contentToTranslate) {
      inputField.dataset.isTranslating = 'false';
      return;
  }

  // UI 置灰锁定反馈
  inputField.style.opacity = '0.5';
  inputField.style.pointerEvents = 'none';
  
  // 2. 检查扩展连接
  if (!chrome.runtime?.id) {
    resetInputState(inputField, originalContent);
    showPersistentReloadAlert();
    return;
  }

  // 3. 触发翻译
  chrome.runtime.sendMessage({
    type: 'TRANSLATE',
    text: contentToTranslate,
    targetLang: settings.targetLang || 'en',
    engine: settings.engine || 'google'
  }, (response) => {
    if (chrome.runtime.lastError) {
      resetInputState(inputField, originalContent);
      showToast(`系统错误: ${chrome.runtime.lastError.message}`);
      return;
    }
    
    if (response && response.success) {
      const translatedText = response.data;
      
      // 4. 完全替换：确保没有任何中文残留
      inputField.focus();
      
      try {
          // A. 物理清空所有节点
          inputField.innerHTML = '';
          
          // B. 插入译文
          let success = document.execCommand('insertText', false, translatedText);
          
          if (!success) {
            inputField.innerText = translatedText;
          }
      } catch (e) {
          console.error('Replacement failed:', e);
          inputField.innerText = translatedText;
      }
      
      // C. 强制同步状态
      inputField.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true }));

      // 5. 执行发送 (不再做中文检测)
      if (autoSend) {
         setTimeout(() => {
           const sendBtn = document.querySelector('button span[data-icon="send"]')?.closest('button') 
                        || document.querySelector('button[aria-label="Send"]')
                        || document.querySelector('button[aria-label="发送"]');
           
           if (sendBtn) {
             sendBtn.click();
           } else {
             const enterEvent = new KeyboardEvent('keydown', { 
               key: 'Enter', code: 'Enter', keyCode: 13, which: 13,
               bubbles: true, cancelable: true
             });
             Object.defineProperty(enterEvent, 'isAutoSend', { value: true });
             inputField.dispatchEvent(enterEvent);
           }
           
           // 发送后解锁
           inputField.dataset.isTranslating = 'false';
           inputField.style.opacity = '1';
           inputField.style.pointerEvents = 'auto';
         }, 150);
      } else {
         // 非自动发送模式，替换后直接解锁
         inputField.dataset.isTranslating = 'false';
         inputField.style.opacity = '1';
         inputField.style.pointerEvents = 'auto';
      }
    } else {
        // 6. 翻译失败：恢复原文并提示
        resetInputState(inputField, originalContent);
        showToast(`⚠️ 翻译失败，请检查网络`);
    }
  });
}
 
 // 简单的提示框
function showToast(msg) {
  const toast = document.createElement('div');
  toast.innerText = msg;
  toast.setAttribute('style', `
    position: fixed;
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    background: rgba(0,0,0,0.8);
    color: white;
    padding: 8px 16px;
    border-radius: 4px;
    z-index: 99999;
    font-size: 14px;
    pointer-events: none;
    transition: opacity 0.3s;
  `);
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 2000);
}

// 严格检测是否为纯英文（无任何中文字符及中文标点）
function isPureEnglish(text) {
    if (!text) return true;
    // 匹配规则：仅允许英文、数字、空格及常用英文标点。
    // 如果含有任何中文字符（\u4e00-\u9fa5）或全角字符，则返回 false。
    return !/[\u4e00-\u9fa5\u3000-\u303f\uff00-\uffef]/.test(text);
}

// 强制刷新提示 (Context Invalidated 时显示)
function showPersistentReloadAlert() {
    if (document.getElementById('wa-reload-alert')) return;
    
    const alertBox = document.createElement('div');
    alertBox.id = 'wa-reload-alert';
    alertBox.innerHTML = `
        <div style="font-weight: bold; margin-bottom: 4px;">⚠️ 插件已更新</div>
        <div>检测到扩展上下文已失效，请立即刷新页面以恢复翻译功能。</div>
        <button id="wa-reload-btn" style="margin-top: 8px; background: white; color: #d32f2f; border: none; padding: 4px 12px; border-radius: 4px; cursor: pointer; font-weight: bold;">立即刷新</button>
    `;
    alertBox.setAttribute('style', `
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: #d32f2f;
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        z-index: 2147483647;
        font-size: 14px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        text-align: center;
        animation: waSlideDown 0.3s ease-out;
    `);
    
    document.body.appendChild(alertBox);
    
    document.getElementById('wa-reload-btn').addEventListener('click', () => {
        window.location.reload();
    });
}
