const https = require('https');

const orderId = 'ORDER_1770875272409';

// Try GET /api/pay/check?order_id=...
const path = `/api/pay/check?order_id=${orderId}`;

const options = {
  hostname: 'nexusproxy.asia',
  path: path,
  method: 'GET'
};

console.log('Testing:', path);

const req = https.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    console.log('Status:', res.statusCode);
    console.log('Body:', body);
  });
});

req.on('error', (e) => {
  console.error(e);
});

req.end();