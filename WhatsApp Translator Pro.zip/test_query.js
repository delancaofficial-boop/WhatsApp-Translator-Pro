const https = require('https');

const orderId = 'ORDER_1770875272409'; // Use the one from previous output

// Try GET /api/pay/query?out_trade_no=...
const path = `/api/pay/query?out_trade_no=${orderId}`;

const options = {
  hostname: 'nexusproxy.asia',
  path: path,
  method: 'GET'
};

console.log('Testing:', path);

const req = https.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    console.log('Status:', res.statusCode);
    console.log('Body:', body);
  });
});

req.on('error', (e) => {
  console.error(e);
});

req.end();