// 存储 API Keys (实际开发中建议让用户在设置页面输入)
const API_KEYS = {
  google: 'AIzaSyDM1CPJnxMYHv72hp9Jpd8oNuWPN6hFsOs',
  deepl: 'YOUR_DEEPL_AUTH_KEY'
};

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'TRANSLATE') {
    // 增加会员校验：从 storage 获取 user 信息并校验
    chrome.storage.local.get(['user', 'isLoggedIn'], (res) => {
        if (!res.isLoggedIn) {
            console.warn('Translation blocked: User not logged in.');
            sendResponse({success: false, error: '请先登录插件后再使用翻译功能'});
            return;
        }

        const user = res.user;
        if (!isMembershipValid(user)) {
            console.warn('Translation blocked: Membership invalid or expired.');
            sendResponse({success: false, error: '会员已到期或未开通，请续费后使用'});
            return;
        }

        console.log('Starting translation for:', request.text.substring(0, 50) + '...');
        
        // 生成一个唯一的 User ID 用于 Google Quota 限制 (使用 email 的 hash)
        const quotaUser = user ? btoa(user.email || 'guest').substring(0, 10) : 'anonymous';

        translateText(request.text, request.targetLang, request.engine, quotaUser)
          .then(translatedText => {
              console.log('Translation success');
              sendResponse({success: true, data: translatedText});
          })
          .catch(error => {
              console.error('Translation failed after all attempts:', error);
              sendResponse({success: false, error: error.message});
          });
    });
    return true; // 保持异步
  }

  if (request.type === 'DETECT_LANGUAGE') {
    chrome.i18n.detectLanguage(request.text, (result) => {
      if (result && result.languages && result.languages.length > 0) {
        // 返回概率最高的语言
        const sorted = result.languages.sort((a, b) => b.percentage - a.percentage);
        sendResponse({success: true, lang: sorted[0].language});
      } else {
        sendResponse({success: false});
      }
    });
    return true;
  }
});

// 会员有效性检查辅助函数 (同步 popup.js 逻辑)
function isMembershipValid(user) {
    if (!user) return false;
    // 同时支持 expiry_date 和 expire_at 字段
    const expireDate = user.expiry_date || user.expire_at;
    if (expireDate === '永久' || expireDate === '永久会员') return true;
    if (!expireDate || expireDate === '未开通' || expireDate === '无') return false;

    try {
        const now = new Date();
        // 获取北京时间 (UTC+8)
        const beijingOffset = 8 * 60; // 分钟
        const localOffset = now.getTimezoneOffset(); // 分钟
        const beijingTime = new Date(now.getTime() + (beijingOffset + localOffset) * 60000);
        
        const y = beijingTime.getFullYear();
        const m = String(beijingTime.getMonth() + 1).padStart(2, '0');
        const d = String(beijingTime.getDate()).padStart(2, '0');
        const todayStr = `${y}-${m}-${d}`;

        // 字符串比较即可: "2024-05-21" >= "2024-05-20"
        return expireDate >= todayStr;
    } catch (e) {
        console.error('Membership date check failed:', e);
        return false;
    }
}

// 监听快捷键命令
chrome.commands.onCommand.addListener((command) => {
  if (command === 'quick-translate') {
    // 查找当前激活的标签页，并发送消息给 Content Script
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      if (tabs[0]?.id && tabs[0].url?.includes('web.whatsapp.com')) {
        chrome.tabs.sendMessage(tabs[0].id, {type: 'TRIGGER_QUICK_TRANSLATE'});
      }
    });
  }
});

async function translateText(text, targetLang, engine = 'google', quotaUser = 'default') {
  if (engine === 'deepl') {
    return translateDeepL(text, targetLang);
  } else {
    return translateGoogle(text, targetLang, quotaUser);
  }
}

// Google 翻译调用 (官方 API 版)
async function translateGoogle(text, targetLang, quotaUser = 'default') {
  try {
    // 目标语言映射
    let tl = targetLang;
    if (tl === 'zh') tl = 'zh-CN';
    
    // 使用官方 Google Cloud Translation API (v2)
    // 添加 quotaUser 参数以识别不同用户，减少 User Rate Limit Exceeded 的概率
    const url = `https://translation.googleapis.com/language/translate/v2?key=${API_KEYS.google}&quotaUser=${quotaUser}`;
    
    const response = await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            q: text,
            target: tl,
            format: 'text'
        })
    });

    if (!response.ok) {
        const errorData = await response.json();
        const errorMsg = errorData.error?.message || response.status;
        console.warn(`Official Google API failed (${response.status}): ${errorMsg}. Trying fallback...`);
        
        // 任何 API 错误都触发降级，确保用户体验
        return translateGoogleFree(text, targetLang);
    }

    const result = await response.json();
    
    if (result && result.data && result.data.translations && result.data.translations[0]) {
        return result.data.translations[0].translatedText;
    } else {
        console.warn('Official API response format invalid, trying fallback...');
        return translateGoogleFree(text, targetLang);
    }

  } catch (e) {
    console.error('Exception in translateGoogle, trying fallback:', e);
    return translateGoogleFree(text, targetLang);
  }
}

// 免费版作为兜底逻辑 (增强版：强制全量 POST)
async function translateGoogleFree(text, targetLang) {
  try {
    let tl = targetLang;
    if (tl === 'zh') tl = 'zh-CN';
    
    // 策略调整：不再区分长短文本，统一使用 POST。
    // 原因：GET 请求在处理某些特殊字符或多字节字符（如中文）时，
    // 即使长度未超标，也可能因为 URL 编码问题导致 400 错误或被截断。
    // POST 是最稳妥的方式。
    const url = "https://translate.googleapis.com/translate_a/single?client=gtx&dt=t";

    const params = new URLSearchParams();
    params.append('sl', 'auto');
    params.append('tl', tl);
    params.append('q', text);
    
    const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: params.toString()
    });

    if (response.ok) {
        const result = await response.json();
        // 拼接所有片段
        return result[0].map(segment => segment[0]).join('');
    }
    
    console.warn('Free API failed:', response.status);
    throw new Error('翻译服务暂时繁忙，请稍后再试');
  } catch (e) {
    console.error('Free API Exception:', e);
    // 抛出具体的错误信息给前端展示
    throw new Error('翻译失败 (网络或服务异常)');
  }
}

// DeepL 翻译调用示例
async function translateDeepL(text, targetLang) {
  const url = 'https://api-free.deepl.com/v2/translate';
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `DeepL-Auth-Key ${API_KEYS.deepl}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: `text=${encodeURIComponent(text)}&target_lang=${targetLang.toUpperCase()}`
  });
  const result = await response.json();
  return result.translations[0].text;
}

// --- 站内信轮询逻辑 ---
const POLLING_INTERVAL_MINUTES = 10;
const API_BASE_URL = "https://nexusproxy.asia";

// 初始化或更新 Alarm
chrome.runtime.onInstalled.addListener(() => {
    chrome.alarms.create('checkStationLetters', {
        periodInMinutes: POLLING_INTERVAL_MINUTES
    });
});

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'checkStationLetters') {
        pollStationLetters();
    }
});

// 轮询核心函数
function pollStationLetters() {
    chrome.storage.local.get(['user', 'isLoggedIn'], (res) => {
        if (!res.isLoggedIn || !res.user) return;
        
        const user = res.user;
        const username = user.username || user.identifier || (user.email ? user.email.split('@')[0] : null);
        
        if (!username) return;

        fetch(`${API_BASE_URL}/api/user/station_letters?username=${encodeURIComponent(username)}`)
            .then(response => response.json())
            .then(result => {
                const messages = Array.isArray(result) ? result : (result.data || []);
                if (!Array.isArray(messages) || messages.length === 0) {
                     chrome.action.setBadgeText({ text: '' });
                     return;
                }

                const storageKey = `readIds_${username}`;
                chrome.storage.local.get([storageKey], (storage) => {
                    const readIds = (storage[storageKey] || []).map(String);
                    const unreadCount = messages.filter(msg => !readIds.includes(String(msg.id))).length;
                    
                    if (unreadCount > 0) {
                        chrome.action.setBadgeText({ text: unreadCount > 99 ? '99+' : String(unreadCount) });
                        chrome.action.setBadgeBackgroundColor({ color: '#f44336' });
                    } else {
                        chrome.action.setBadgeText({ text: '' });
                    }
                });
            })
            .catch(err => console.error('Polling station letters failed:', err));
    });
}
